import pytest
import math
from math import sin
import numpy as np

def test_zeros( ):
    assert sin(0) == 0
    assert math.isclose(sin(-math.pi), 0, abs_tol = 1e-09)
    assert math.isclose(sin(math.pi), 0, abs_tol = 1e-09)
    assert math.isclose(sin(3 * math.pi), 0, abs_tol = 1e-09)

def test_one( ):
    assert math.isclose(sin(math.pi/2), 1, abs_tol = 1e-09)

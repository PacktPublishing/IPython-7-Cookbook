import pytest
from qsort2 import quickSort
import numpy as np

def test_length( ):
    a = np.random.randint(0, 300, 17)
    b = quickSort(a)
    assert len(a) == len(b)

def test_ascending( ):
    a = np.random.randint(0, 300, 17)
    b = quickSort(a)
    for i in range(1, len(b)):
        assert b[i] >= b[i-1]

def test_exception( ):
    a = ['s', 15]
    with pytest.raises(TypeError):
        b = quickSort(a)

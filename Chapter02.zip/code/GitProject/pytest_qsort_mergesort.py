import pytest
from qsort2 import quickSort
from mergesort import merge_sort
import numpy as np

@pytest.mark.parametrize('arrA', [[1, 8, 4, 2], [31, 13, 6, 5, 19]])

def test_equal(arrA):
    q = quickSort(arrA)
    m = merge_sort(arrA)
    assert len(q) == len(m)
    for i in range(len(q)):
        assert q[i] == m[i]

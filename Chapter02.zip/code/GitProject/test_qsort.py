import unittest
from qsort2 import quickSort
import numpy as np

class TestQuickSort(unittest.TestCase):
    def setUp(self):
        self.a = np.random.randint(0, 300, 17)
        self.b = quickSort(self.a)

    def test_length(self):
        self.assertEqual(len(self.a), len(self.b))

    def test_ascending(self):
        for i in range(1, len(self.b)):
            self.assertGreaterEqual(self.b[i], self.b[i-1])

if __name__ == '__main__':
    unittest.main( )

import pytest
from qsort2 import quickSort
import numpy as np

def test_empty_list( ):
    a = [ ]
    b = quickSort(a)
    assert len(b) == 0

def test_one_element_list( ):
    a = [5]
    b = quickSort(a)
    assert len(b) == 1
    assert b[0] == 5

def test_smallest_first( ):
    a = np.random.randint(0, 300, 17)
    np.insert(a, 0, -1)
    b = quickSort(a)
    for i in range(1, len(b)):
        assert b[i] >= b[i-1]

def test_biggest_first( ):
    a = np.random.randint(0, 300, 17)
    np.insert(a, 0, 301)
    b = quickSort(a)
    for i in range(1, len(b)):
        assert b[i] >= b[i-1]

def test_already_sorted_in_ascending_order( ):
    a = np.random.randint(0, 300, 17)
    a.sort( )
    b = quickSort(a)
    for i in range(1, len(b)):
        assert b[i] >= b[i-1]

def test_already_sorted_in_descending_order( ):
    a = np.random.randint(0, 300, 17)
    a.sort( )
    a = a[::-1]
    b = quickSort(a)
    for i in range(1, len(b)):
        assert b[i] >= b[i-1]


import pytest
from qsort2 import quickSort
from mergesort import merge_sort
import numpy as np

@pytest.fixture
def create_new_random_array( ):
    a = np.random.randint(0, 300, 17)
    q = quickSort(a)
    m = merge_sort(a)
    return a, q, m

def test_equal_length(create_new_random_array):
    a, q, m = create_new_random_array
    assert len(q) == len(m)
    for i in range(len(q)):
        assert q[i] == m[i]

def test_ascending(create_new_random_array):
    a, q, m = create_new_random_array

    for i in range(1, len(q)):
        assert q[i] >= q[i-1]

    for i in range(1, len(m)):
        assert m[i] >= m[i-1]

import IPython

a = 42
IPython.embed( )
print(a)

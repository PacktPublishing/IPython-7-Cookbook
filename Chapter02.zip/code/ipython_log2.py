# IPython log file

get_ipython().run_line_magic('run', 'ipython_log.py')
